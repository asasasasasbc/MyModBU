名称: Hunter's Combat V0.6 猎人战斗风格Mod V0.6
作者: Forsakensilver(遗忘的银灵)

此Mod用血源诅咒的武器动作替换了部分黑魂三的武器&对应的动作：
刺剑->螺纹手杖【普通形态】
鞭子->螺纹手杖【鞭子形态】
轻弩->伊芙琳

此模组也替换了刺剑的处决/背刺动画为血源诅咒的内脏暴击。
另外也为伊芙琳加入了枪反的动作。

另外也将这些武器的战技动画替换为了变形斩（但还需要消耗魔力的）。
如果你按照EquipmentBestPractice.png上的装备的话，能实现最好变形武器&变形斩的效果~这是黑魂里很难体会到的。

安装步骤：
1。安装 Mod Engine (https://www.nexusmods.com/darksouls3/mods/332)
2。复制 parts/chr/mtd文件夹到你的 mod 文件夹内。

或者采用UXM压缩进游戏~

By遗忘的银灵

------------------------------------------------------------------------------------------------------


这只是Mod的V0.5版本，我会于之后的更新中加入额外待定的两个或三个血源变形武器，敬请期待。
至其它的Mod制作者：请随意把本Mod加入您的Mod之中，只要您记得鸣谢我即可。
To other mod developer: feel free to modify and merge this mod with your own mod, just don't forget to credit me.
至黑魂/血源玩家：我很想看到你们用这个Mod里的武器通关黑魂三，如果你们能把视频上传到youtube，我会很高兴的。
To Dark Souls/ Bloodborne player: I alreay wish you can beat the whole DS3 with this mod's weapons. I will be really appreciate if you can make a speedrun/ all boss video with this mod's weapon.
If you have done so, please comment with your video link. I will be super happy to watch!


我知道目前还是有很多Bug存在，其中一些我会在之后修复的：
1。武器音效
2。当左手有十字弩的时候，你得按两下左手重攻击键才能实施变形斩
3。鞭子没有下落攻击以及内脏暴击动作
4。并非所有动作都和血源原版意义一一对应，比如跑攻和手杖的变形斩
5。没有单独的变形动作。武器射击时走动会导致动画出现瑕疵。
6。血源滑步只替换了中重量的翻滚。



鸣谢清单: 
并非NEP for General help
GodFilm for TAE editing help
Itzli for The Bloodborne Dash Mod. This mod included that dash mod, so, a huge credit here.
TKGP for the Souls Formats library/ Yabber.
Meowmaritus for DS Anim Studio, it is super useful.
Mayhem for sharing his animation workflow and root motion fixer
Sony for helping me learn the motion builder(?)
 