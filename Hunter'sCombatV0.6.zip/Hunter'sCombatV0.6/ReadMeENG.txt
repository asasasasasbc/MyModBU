Hunter's Combat V0.6

Author: Forsakensilver
This mod added bloodborne style trick weapons & visceral attack & firearm parry to the dark souls 3.

It replaced some original DS3 weapons animation with Bloodborne's:
Estoc -> Threaded cane (not transformed)
Whip-> Threaded cane (transformed)
Light crossbow -> Evelyn
This mod also replaced Estoc's riposte & backstab animation with BB's visceral attack.
Added parrying & quick shoot functionality for Evelyn.
And also replaced the war art of these weapons with trick weapon's transform attack (still costs mana though).
If you are using war arts of these weapons and you equipped only Estoc and Whip (both equipped, check the EquipmentBestPractice.png), you can 
achieve some sweet trick weapon transform attack~
Installation
Install and configure Mod Engine(https://www.nexusmods.com/darksouls3/mods/332) as described on its page
Copy the parts/ chr /mtd folder in side the zip file into your mod directory

Alternative way of installation (Thanks to AMARANTHE000NEXUS)
1. Unpack with UXM 2.1.3.
2. Back up the original "parts" and  "chr" folder. (optional)
3. Overwrite the "parts" and "chr" folder with the folders inside the zip file.
4. Pack everything using UXM

------------------------------------------------------------------------------------------------------

This is only the v0.5 version, in the future I am going port another two or three  classic trick weapons, maybe hunter's axe, rakuyo, etc.
To other mod developer: feel free to modify and merge this mod with your own mod, just don't forget to credit me.
To Dark Souls/ Bloodborne players: I really wish you can beat the whole DS3 with this mod's weapons. I will be really appreciate if you can make a speedrun/ all boss video with this mod's weapon.
If you have done so, please comment with your video link. I will be super happy to watch!


I know there are some existing bugs, some of which will be fixed in future updates:
1. Weapon's sound effects.
2. Perform limited transformation attack when equipped with left hand crossbow. 
(You need to press left heavy atk btn twice with no arrow equipped in the second arrow slot.)
3. Whip don't have falling & visceral attack animation. (Because of DS3 system.)
4. Some attack animation not exactly the same as Bloodborne's.(i.e. running attack and cane's transformation attack)
5. Shooting while walking animation broken (because in BB shooting animation does not move.)
6. Only Middle roll is replaced by bloodborne style dash. 
(v0.6 fixed: threaded cane looks black after transformed)

Credit list:
BingfeiNEP for General help
GodFilm for TAE editing help
Itzli for The Bloodborne Dash Mod. This mod included that dash mod, so, a huge credit here.
TKGP for the Souls Formats library.
Meowmaritus for DS Anim Studio, it is super useful.
Mayhem for sharing his animation workflow and root motion fixer
Sony for helping me learn the motion builder(?)

 